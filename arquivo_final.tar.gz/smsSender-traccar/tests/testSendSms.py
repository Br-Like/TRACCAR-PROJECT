from app.services.sendsms import sendSMS

def testSendSms():
    sendSMS("mensage", "35992493592")
testSendSms()
