from fastapi import APIRouter, Request, status


router = APIRouter()

@router.get("/")
def hello_world():
    return {"status":"ok"}

@router.get("/api/send_sms", status_code=status.HTTP_200_OK)
def hello_world2():
    return {"status":"ok"}

@router.post("/api/send_sms", status_code=status.HTTP_200_OK)
async def send_sms(request: Request):
    data = await request.json()
    email = data.get("email")

    from app.services.sendTraccarNewPassword import sendNewPassword
    response = sendNewPassword(email)

    return response
