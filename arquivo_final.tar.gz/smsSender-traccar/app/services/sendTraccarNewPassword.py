import os
import secrets
import string

import requests
from dotenv import load_dotenv

from app.services.sendsms import sendSMS

load_dotenv()

host = str(os.getenv("TRACCAR_HOST", ""))
port = str(os.getenv("TRACCAR_PORT", ""))
adminEmail = str(os.getenv("TRACCAR_EMAIL", ""))
adminPassword = str(os.getenv("TRACCAR_PASSWORD", ""))

url = f"{host}:{port}" if port else host

def createPassword(length: int = 8) -> str:
    """
    Gera uma senha aleatória contendo letras maiúsculas,
    minúsculas e números.
    """

    characters = string.ascii_letters + string.digits

    return "".join(
        secrets.choice(characters)
        for _ in range(length)
    )


def FormatMensageSMS(client: dict, password: str) -> str:
    """
    Formata a mensagem que será enviada ao cliente.
    """

    return (
        f"Olá {client['name']}, "
        f"sua senha agora no Traccar é {password}."
    )



def getCookieAdmin() -> str:
    """
    Realiza login no Traccar e retorna o JSESSIONID.
    """

    response: requests.Response = requests.post(
        f"{url}/api/session",
        data={
            "email": adminEmail,
            "password": adminPassword
        },
        headers={
            "Content-Type": "application/x-www-form-urlencoded"
        },
        verify=False
    )

    if response.status_code != 200:
        raise ValueError(
            f"Falha na autenticação do Traccar: "
            f"{response.status_code} - {response.text}"
        )

    jsessionid = response.cookies.get("JSESSIONID")

    if not jsessionid:
        raise ValueError(
            "Erro ao coletar o cookie JSESSIONID do administrador"
        )

    return jsessionid


def getUsers(adminCookie: str) -> list:
    """
    Busca os usuários do Traccar.
    """

    response: requests.Response = requests.get(
        f"{url}/api/users",
        params={
            "excludeAttributes": "false",
            "limit": 200,
            "offset": 0
        },
        cookies={
            "JSESSIONID": adminCookie
        },
        verify=False
    )

    if response.status_code != 200:
        raise ValueError(
            f"Falha ao buscar usuários: "
            f"{response.status_code} - {response.text}"
        )

    return response.json()


def alterPassword(
    adminCookie: str,
    user: dict,
    password: str
) -> None:
    """
    Altera a senha do usuário no Traccar.
    """

    user["password"] = password

    response: requests.Response = requests.put(
        f"{url}/api/users/{user['id']}",
        cookies={
            "JSESSIONID": adminCookie
        },
        json=user,
        verify=False
    )

    if response.status_code != 200:
        raise ValueError(
            f"Falha ao alterar senha do usuário: "
            f"{response.status_code} - {response.text}"
        )


def sendNewPassword(userName: str):
    """
    Localiza o usuário pelo e-mail, altera sua senha
    e envia a nova senha por SMS.
    """

    try:

        adminCookie = getCookieAdmin()

        users = getUsers(adminCookie)

        for client in users:

            if client.get("email") != userName:
                continue

            phone = client.get("phone")

            if not phone:
                return {
                    "erro": "Usuário encontrado, mas não possui telefone cadastrado."
                }

            newPassword = createPassword(8)

            alterPassword(
                adminCookie,
                client,
                newPassword
            )


            message = FormatMensageSMS(
                client,
                newPassword
            )
            print(f"{phone}: {message}", flush=True)
            sendSMS(
                phone,
                message
            )

            return {
                "sucesso": True,
                "mensagem": "Nova senha enviada por SMS."
            }

        # ----------------------------------------------------
        # Usuário não encontrado
        # ----------------------------------------------------

        return {
            "erro": "Usuário não encontrado. Confira seu e-mail."
        }

    except requests.RequestException as e:

        return {
            "erro": f"Erro de comunicação com o Traccar: {str(e)}"
        }

    except ValueError as e:

        return {
            "erro": str(e)
        }

    except Exception as e:

        return {
            "erro": f"Erro inesperado: {str(e)}"
        }
