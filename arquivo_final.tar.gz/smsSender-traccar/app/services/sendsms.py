import http.client
import json
import re
import base64
import os
from dotenv import load_dotenv

load_dotenv()

PHONE_PATTERN: str = r'^(?:\d{11}|\(\d{2}\)\d{8,9}|\(\d{2}\)\d{4,5}-\d{4})$'

maxLengthSms = lambda x: 'Message exceeds 255 characters' if len(x) > 255 else ''
maxLengthPhoneNumber = lambda x: 'Invalid phone number format' if not re.match(PHONE_PATTERN, x) else ''

def validateMensage(message: str, number: str):
    error = maxLengthSms(message)
    if error:
        raise ValueError(error)

    error = maxLengthPhoneNumber(number)
    if error:
        raise ValueError(error)

def sendSMS(number: str, mensage: str):
    username = os.getenv("SMSUSER")
    password = os.getenv("SMSPASSWORD")
    credentials = f"{username}:{password}"
    encoded = base64.b64encode(credentials.encode()).decode()

    conn = http.client.HTTPSConnection("api.hotmobile.com.br")
    try:
        validateMensage(mensage, number)
    except ValueError as e:
        print(e, flush=True)
        return

    payload = {
                "mensagem":mensage,
                "centroDeCusto":None,
                "idExterno":None,
                "arquivoWhatsApp":None,
                "instanciaId":None,
                "listNumeros":[
                    {"numero": number}
                ]
            }

    headers = {
        'Content-Type': "application/json",
        'Authorization': f"Basic {encoded}"
    }

    conn.request("POST", "/Sms/EnviarMensagem", json.dumps(payload), headers)

    res = conn.getresponse()
    print(res)
    data = res.read()

    print(data.decode("utf-8"))
